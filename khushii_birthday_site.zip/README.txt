Happy Birthday Khushii — Website bundle
Files:
- index.html
- styles.css
- script.js
- assets/photo.svg (placeholder image)
- assets/song.wav (3s placeholder tone)

How to use:
1. Unzip and upload all files to a GitHub repository.
2. Enable GitHub Pages (Settings -> Pages -> Deploy from main branch) to host the site.
3. Replace assets/photo.svg with your real photos (keep path or update index.html).
4. Replace assets/song.wav with the actual song file (e.g., Roke Na Ruke Naina) named 'song.wav' if you want autoplay to play that file. Note: browsers may block autoplay with sound; clicking the Play button will work reliably.
